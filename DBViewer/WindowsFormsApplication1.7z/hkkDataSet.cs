﻿namespace WindowsFormsApplication1 {
    
    
    public partial class hkkDataSet {
    }
}

namespace WindowsFormsApplication1.hkkDataSetTableAdapters {
    
    
    public partial class lapTableAdapter {
    }
}
